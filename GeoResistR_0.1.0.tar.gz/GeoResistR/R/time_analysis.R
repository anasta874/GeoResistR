#' Analyze temporal trends in resistance genes
#'
#' @param data A data frame with resistome data
#' @return A data frame with average abundance of each gene over time
#' @export
analyze_time_trend <- function(data) {
  # Отладочная печать входных данных
  print("Initial data:")
  print(head(data))
  print(unique(data$gene_id))
  print(summary(data$date))
  print(summary(data$abundance))

  # Проверка и преобразование формата даты
  data$date <- as.Date(data$date, format = "%Y-%m-%d")

  # Группировка и вычисление среднего
  data_time <- dplyr::summarize(
    dplyr::group_by(data, gene_id, date),
    mean_abundance = mean(abundance, na.rm = TRUE),
    .groups = "drop" # Убираем группировку
  )

  # Отладочная печать результата
  print("Grouped data with mean abundance:")
  print(head(data_time))

  return(data_time)
}

#' Plot temporal trends for a specific resistance gene
#'
#' @param data_time A data frame with time trend data (output of analyze_time_trend)
#' @param gene_id The gene ID to plot (e.g., "blaCTX-M-15")
#' @return A ggplot object with the time trend
#' @export
plot_time_trend <- function(data_time, gene_id) {
  # Фильтрация по gene_id
  gene_data <- dplyr::filter(data_time, gene_id == !!gene_id)

  # Отладочная информация
  print(paste("Filtered data for gene:", gene_id))
  print(gene_data)

  # Создание графика
  p <- ggplot2::ggplot(gene_data, ggplot2::aes(x = date, y = mean_abundance)) +
    ggplot2::geom_line(color = "#2C7FB8", size = 0.5) +
    ggplot2::geom_point(color = "red", size = 0.5) +
    ggplot2::geom_smooth(method = "loess", se = FALSE, color = "#F03B20", size = 1) +
    ggplot2::labs(
      title = paste("Time Trend for", gene_id),
      x = "Date",
      y = "Mean Abundance"
    ) +
    ggplot2::theme_minimal()

  print(p)
  return(p)
}

