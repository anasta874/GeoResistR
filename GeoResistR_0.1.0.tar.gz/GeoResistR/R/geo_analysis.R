#' Plot geographical distribution of a specific resistance gene within data bounds
#'
#' @param data A data frame with resistome data
#' @param gene_id The gene identifier to visualize
#' @return A ggplot object showing the geographical distribution of the gene's abundance on a map
#' @export
plot_geo_distribution <- function(data, gene_id) {
  # Проверяем наличие необходимых столбцов
  if (!all(c("longitude", "latitude", "abundance") %in% colnames(data))) {
    stop("The dataset must contain 'longitude', 'latitude', and 'abundance' columns.")
  }

  # Фильтруем данные для конкретного гена
  gene_data <- dplyr::filter(data, gene_id == !!gene_id)

  # Преобразуем данные в формат sf
  gene_sf <- sf::st_as_sf(gene_data, coords = c("longitude", "latitude"), crs = 4326)

  # Устанавливаем границы карты с отступом
  buffer <- 2  # Отступ в градусах
  xlim <- range(gene_data$longitude, na.rm = TRUE) + c(-buffer, buffer)
  ylim <- range(gene_data$latitude, na.rm = TRUE) + c(-buffer, buffer)

  # Загрузка карты мира с использованием rnaturalearth
  world <- rnaturalearth::ne_countries(scale = "medium", returnclass = "sf")

  # Построение графика
  p <- ggplot2::ggplot(data = world) +
    ggplot2::geom_sf(fill = "gray90", color = "gray50") +  # Фон карты
    ggplot2::geom_sf(data = gene_sf, ggplot2::aes(size = abundance), color = "#2c7fb8", alpha = 0.6) +  # Точки
    ggplot2::coord_sf(xlim = xlim, ylim = ylim, expand = FALSE) +  # Ограничиваем вид карты границами данных
    ggplot2::labs(
      title = paste("Geographical Distribution for", gene_id),
      x = "Longitude",
      y = "Latitude",
      size = "Abundance"
    ) +
    ggplot2::theme_minimal() +
    ggplot2::theme(
      plot.title = ggplot2::element_text(face = "bold", size = 14, hjust = 0.5),
      axis.title = ggplot2::element_text(size = 12),
      axis.text = ggplot2::element_text(size = 10)
    )

  return(p)
}





