#' Create a forecast for abundance data
#'
#' @param data_time A filtered data frame with time trend data for one gene
#' @param h Number of future periods to forecast
#' @return A list with mean, lower, and upper predictions
#' @export
forecast_abundance <- function(data_time, gene_id, h = 10) {
  # Фильтруем данные для указанного гена
  filtered_data <- dplyr::filter(data_time, gene_id == !!gene_id)

  # Проверяем, что данные существуют
  if (nrow(filtered_data) == 0) {
    stop(paste("No data found for gene:", gene_id))
  }

  # Убедимся, что даты корректны
  filtered_data$date <- as.Date(filtered_data$date)

  # Упорядочиваем данные по дате
  filtered_data <- dplyr::arrange(filtered_data, date)

  # Создаем линейную модель
  model <- lm(mean_abundance ~ date, data = filtered_data)

  # Генерируем будущие даты
  future_dates <- data.frame(
    date = seq(
      from = max(filtered_data$date) + 1,
      by = "month",
      length.out = h
    )
  )

  # Прогноз
  forecast_result <- predict(model, newdata = future_dates, interval = "confidence")

  # Возвращаем результаты прогноза как список
  return(list(
    mean = as.numeric(forecast_result[, "fit"]),
    lower = as.numeric(forecast_result[, "lwr"]),
    upper = as.numeric(forecast_result[, "upr"])
  ))
}

#' Plot temporal trends and forecast on the same graph
#'
#' @param data_time A data frame with time trend data
#' @param forecast_result The forecast object created by `forecast_abundance`
#' @param gene_id The gene ID to plot (e.g., "blaCTX-M-15")
#' @return A ggplot object showing the temporal trend and forecast
#' @export
plot_combined_trend_and_forecast <- function(data_time, forecast_result, gene_id) {
  # Фильтруем данные для указанного гена
  original_data <- dplyr::filter(data_time, gene_id == !!gene_id)

  # Проверяем, что данные для данного гена существуют
  if (nrow(original_data) == 0) {
    stop(paste("No data found for gene:", gene_id))
  }

  # Убедимся, что даты корректны
  original_data$date <- as.Date(original_data$date)

  # Создаем data frame для прогноза
  forecast_df <- data.frame(
    date = seq.Date(
      from = max(original_data$date) + 1,
      by = "month",
      length.out = length(forecast_result$mean)
    ),
    mean = forecast_result$mean,
    lower = forecast_result$lower,
    upper = forecast_result$upper
  )

  # Отладочная информация
  print(paste("Filtered data for gene:", gene_id))
  print(head(original_data))
  print(summary(original_data))

  # Построение графика
  ggplot2::ggplot() +
    # Оригинальные данные (точки)
    ggplot2::geom_point(
      data = original_data,
      ggplot2::aes(x = date, y = mean_abundance),
      color = "red", size = 0.8
    ) +
    # Оригинальные данные (линия)
    ggplot2::geom_line(
      data = original_data,
      ggplot2::aes(x = date, y = mean_abundance),
      color = "#2c7fb8", size = 0.5
    ) +
    # Сглаженная линия для оригинальных данных
    ggplot2::geom_smooth(
      data = original_data,
      ggplot2::aes(x = date, y = mean_abundance),
      method = "loess",
      se = FALSE,
      color = "#f03b20", size = 1
    ) +
    # Прогнозируемые значения (линия)
    ggplot2::geom_line(
      data = forecast_df,
      ggplot2::aes(x = date, y = mean),
      color = "red", size = 0.8, linetype = "dashed"
    ) +
    # Интервалы прогноза
    ggplot2::geom_ribbon(
      data = forecast_df,
      ggplot2::aes(x = date, ymin = lower, ymax = upper),
      fill = "pink", alpha = 0.3
    ) +
    # Общие настройки графика
    ggplot2::labs(
      title = paste("Temporal Trend and Forecast for", gene_id),
      x = "Date",
      y = "Mean Abundance"
    ) +
    ggplot2::scale_x_date(
      date_labels = "%b %Y",
      date_breaks = "1 month",
      expand = ggplot2::expansion(mult = c(0.05, 0.1))
    ) +
    ggplot2::scale_y_continuous(
      limits = c(0, max(c(original_data$mean_abundance, forecast_df$upper), na.rm = TRUE) * 1.1),
      expand = ggplot2::expansion(mult = c(0, 0.05))
    ) +
    ggplot2::theme_minimal() +
    ggplot2::theme(
      axis.text.x = ggplot2::element_text(angle = 45, hjust = 1),
      plot.title = ggplot2::element_text(face = "bold", size = 14, hjust = 0.5)
    )
}

